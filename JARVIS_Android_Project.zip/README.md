# JARVIS Android starter

This is a native Android Kotlin starter project (not a website).

## Current features
- Native Android app interface
- Tap-to-speak using Android speech recognition
- Spoken responses using Android TextToSpeech
- Open YouTube, WhatsApp, Maps, Chrome
- Web search and open phone dialler
- Time/date commands

## Important limitations
This first build does NOT implement an always-on custom wake word, AI model connection, WhatsApp message sending, or unrestricted phone settings control. Android restricts background microphone access. A reliable custom wake phrase while the screen is off requires a dedicated wake-word engine and a visible foreground service/notification, with battery and device-specific limitations. It cannot listen while the phone is powered off.

## Build an APK using GitHub Actions (phone-only route)
1. Create a GitHub account if you don't have one.
2. In GitHub, create a new public or private repository named `jarvis-android`.
3. Upload the contents of this ZIP to the repository (upload files from the root, not the ZIP itself).
4. Open the repository's **Actions** tab and enable Actions if asked.
5. The workflow named **Build JARVIS APK** runs after pushing to `main`. You can also choose **Run workflow**.
6. Open the completed workflow run, scroll to **Artifacts**, and download `JARVIS-debug-APK`.
7. Extract the downloaded artifact ZIP on your phone and install `app-debug.apk`. Android may ask you to allow installs from that browser/file manager.

## Requirements
- Android 8.0+ (API 26+)
- Build uses Android Gradle Plugin 8.7.3, Gradle 8.9 and JDK 17.
